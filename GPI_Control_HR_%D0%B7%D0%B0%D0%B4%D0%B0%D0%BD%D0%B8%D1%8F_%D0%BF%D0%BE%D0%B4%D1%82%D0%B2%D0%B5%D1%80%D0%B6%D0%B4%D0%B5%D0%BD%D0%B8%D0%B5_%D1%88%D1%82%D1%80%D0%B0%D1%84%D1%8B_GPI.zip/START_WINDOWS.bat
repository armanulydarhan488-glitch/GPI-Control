@echo off
chcp 65001 >nul
cd /d "%~dp0"
echo GPI Control — локальный сервер
echo Откройте http://127.0.0.1:8000
python server.py
if errorlevel 1 (
 echo.
 echo Не удалось запустить Python. Попробуйте py -3 server.py
 py -3 server.py
)
pause
