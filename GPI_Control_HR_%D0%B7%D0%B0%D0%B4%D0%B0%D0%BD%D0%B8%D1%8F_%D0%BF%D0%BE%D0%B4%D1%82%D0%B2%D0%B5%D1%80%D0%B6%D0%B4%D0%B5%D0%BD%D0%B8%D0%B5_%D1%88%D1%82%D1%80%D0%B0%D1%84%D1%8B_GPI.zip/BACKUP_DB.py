#!/usr/bin/env python3
"""Safe online backup of the local GPI Control SQLite database."""
from datetime import datetime
from pathlib import Path
import sqlite3

ROOT = Path(__file__).resolve().parent
DB = ROOT / 'gpi_data.sqlite3'
if not DB.is_file():
    raise SystemExit('База gpi_data.sqlite3 ещё не создана. Сначала запустите сервер.')
backup_dir = ROOT / 'backups'
backup_dir.mkdir(exist_ok=True)
file = backup_dir / ('gpi_backup_' + datetime.now().strftime('%Y%m%d_%H%M%S') + '.sqlite3')
with sqlite3.connect(DB) as source, sqlite3.connect(file) as destination:
    source.backup(destination)
print('Резервная копия создана:', file)
