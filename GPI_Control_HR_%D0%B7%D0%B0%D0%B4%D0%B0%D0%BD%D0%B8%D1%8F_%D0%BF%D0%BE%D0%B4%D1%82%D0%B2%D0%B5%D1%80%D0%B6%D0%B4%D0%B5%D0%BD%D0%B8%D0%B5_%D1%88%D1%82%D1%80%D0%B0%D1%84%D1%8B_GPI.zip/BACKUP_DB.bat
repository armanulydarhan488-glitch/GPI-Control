@echo off
cd /d "%~dp0"
python BACKUP_DB.py
pause
