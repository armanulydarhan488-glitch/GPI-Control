@echo off
chcp 65001 >nul
cd /d "%~dp0"
python "ВОССТАНОВИТЬ_АДМИНА.py"
if errorlevel 1 py -3 "ВОССТАНОВИТЬ_АДМИНА.py"
pause
