@echo off
chcp 65001 >nul
cd /d "%~dp0"
python "ВОССТАНОВИТЬ_HR.py"
if errorlevel 1 py -3 "ВОССТАНОВИТЬ_HR.py"
pause
