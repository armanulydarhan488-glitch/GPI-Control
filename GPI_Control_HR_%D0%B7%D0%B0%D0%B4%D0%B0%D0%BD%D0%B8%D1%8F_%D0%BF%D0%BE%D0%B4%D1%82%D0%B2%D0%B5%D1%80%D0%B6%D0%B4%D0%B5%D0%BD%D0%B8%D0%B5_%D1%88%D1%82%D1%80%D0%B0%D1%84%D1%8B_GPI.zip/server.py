#!/usr/bin/env python3
"""GPI Control local-network server; Python 3.9+, no packages."""
import copy, hashlib, hmac, json, os, secrets, sqlite3, threading, time
import html, re
from datetime import date, datetime
import urllib.request, urllib.error
import ipaddress
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from http.cookies import SimpleCookie
from pathlib import Path
from urllib.parse import urlsplit, parse_qs
ROOT=Path(__file__).resolve().parent
LOCK=threading.RLock()
SESSIONS={}
AI_RATE={}
PORT=int(os.environ.get('GPI_PORT','8000'))
def conn():
 c=sqlite3.connect(ROOT/'gpi_data.sqlite3',timeout=15)
 c.row_factory=sqlite3.Row
 return c
def hashpass(p,s=None):
 s=s or secrets.token_bytes(16)
 return s.hex()+'$'+hashlib.pbkdf2_hmac('sha256',p.encode(),s,260000).hex()
def validpass(p,h):
 try:
  s,d=h.split('$'); return hmac.compare_digest(hashpass(p,bytes.fromhex(s)).split('$')[1],d)
 except (ValueError,TypeError): return False
def init():
 with LOCK,conn() as c:
  c.execute('CREATE TABLE IF NOT EXISTS state (id INTEGER PRIMARY KEY, rev INTEGER, data TEXT)')
  c.execute("""CREATE TABLE IF NOT EXISTS task_workflows (
   task_id TEXT PRIMARY KEY, status TEXT NOT NULL DEFAULT 'assigned', proposed INTEGER NOT NULL DEFAULT 0,
   note TEXT NOT NULL DEFAULT '', employee_login TEXT NOT NULL DEFAULT '', reviewer TEXT NOT NULL DEFAULT '',
   updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, approved_at TEXT NOT NULL DEFAULT '')""")
  c.execute("""CREATE TABLE IF NOT EXISTS task_penalties (
   task_id TEXT PRIMARY KEY, employee_id TEXT NOT NULL, amount INTEGER NOT NULL,
   reason TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")
  c.execute("""CREATE TABLE IF NOT EXISTS task_audit (
   id INTEGER PRIMARY KEY AUTOINCREMENT, task_id TEXT NOT NULL, actor TEXT NOT NULL,
   action TEXT NOT NULL, details TEXT NOT NULL DEFAULT '', created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)""")

  c.execute("CREATE TABLE IF NOT EXISTS ai_settings (id INTEGER PRIMARY KEY CHECK(id=1), model TEXT NOT NULL DEFAULT '')")
  c.execute("INSERT OR IGNORE INTO ai_settings(id,model) VALUES(1,'')")
  c.execute('CREATE TABLE IF NOT EXISTS users (login TEXT PRIMARY KEY COLLATE NOCASE, passhash TEXT, role TEXT, name TEXT, employeeId TEXT, department TEXT)')
  c.execute('CREATE TABLE IF NOT EXISTS direct_messages (id INTEGER PRIMARY KEY AUTOINCREMENT, sender TEXT NOT NULL, recipient TEXT NOT NULL, body TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)')
  c.execute('CREATE INDEX IF NOT EXISTS dm_conversation ON direct_messages(sender,recipient,id)')
  c.execute('CREATE TABLE IF NOT EXISTS courses (id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, description TEXT NOT NULL DEFAULT "", lessons INTEGER NOT NULL DEFAULT 1, department TEXT NOT NULL DEFAULT "Все", created_by TEXT NOT NULL)')
  c.execute('CREATE TABLE IF NOT EXISTS enrollments (id INTEGER PRIMARY KEY AUTOINCREMENT, course_id INTEGER NOT NULL, login TEXT NOT NULL COLLATE NOCASE, status TEXT NOT NULL DEFAULT "pending", completed INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, UNIQUE(course_id,login))')
  c.execute('CREATE TABLE IF NOT EXISTS training_events (id INTEGER PRIMARY KEY AUTOINCREMENT, recipient TEXT NOT NULL COLLATE NOCASE, message TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, is_read INTEGER NOT NULL DEFAULT 0)')
  c.execute('CREATE TABLE IF NOT EXISTS course_quizzes (course_id INTEGER PRIMARY KEY, questions_json TEXT NOT NULL)')
  c.execute('CREATE TABLE IF NOT EXISTS lesson_quizzes (course_id INTEGER NOT NULL, lesson_number INTEGER NOT NULL, title TEXT NOT NULL, questions_json TEXT NOT NULL, PRIMARY KEY(course_id,lesson_number))')
  c.execute('CREATE TABLE IF NOT EXISTS lesson_materials (course_id INTEGER NOT NULL, lesson_number INTEGER NOT NULL, content_json TEXT NOT NULL, PRIMARY KEY(course_id,lesson_number))')
  c.execute('CREATE TABLE IF NOT EXISTS lesson_quiz_results (course_id INTEGER NOT NULL, lesson_number INTEGER NOT NULL, login TEXT NOT NULL COLLATE NOCASE, score INTEGER NOT NULL, total INTEGER NOT NULL, submitted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(course_id,lesson_number,login))')
  c.execute('CREATE TABLE IF NOT EXISTS quiz_results (course_id INTEGER NOT NULL, login TEXT NOT NULL COLLATE NOCASE, score INTEGER NOT NULL, total INTEGER NOT NULL, submitted_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, PRIMARY KEY(course_id,login))')
  c.execute('''CREATE TABLE IF NOT EXISTS hr_profiles (
    login TEXT PRIMARY KEY COLLATE NOCASE, company TEXT NOT NULL DEFAULT 'GPI Demo',
    position TEXT NOT NULL DEFAULT '', department TEXT NOT NULL DEFAULT '',
    supervisor TEXT NOT NULL DEFAULT '', hire_date TEXT NOT NULL DEFAULT '',
    vacation_balance INTEGER NOT NULL DEFAULT 24)''')
  c.execute('''CREATE TABLE IF NOT EXISTS hr_requests (
    id INTEGER PRIMARY KEY AUTOINCREMENT, login TEXT NOT NULL COLLATE NOCASE,
    kind TEXT NOT NULL, start_date TEXT, end_date TEXT, days INTEGER NOT NULL DEFAULT 0,
    amount INTEGER NOT NULL DEFAULT 0, comment TEXT NOT NULL DEFAULT '',
    status TEXT NOT NULL DEFAULT 'pending', reviewer TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP, updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)''')
  c.execute('''CREATE TABLE IF NOT EXISTS hr_request_history (
    id INTEGER PRIMARY KEY AUTOINCREMENT, request_id INTEGER NOT NULL, actor TEXT NOT NULL,
    event TEXT NOT NULL, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)''')
  c.execute('''CREATE TABLE IF NOT EXISTS hr_notices (
    id INTEGER PRIMARY KEY AUTOINCREMENT, recipient TEXT NOT NULL COLLATE NOCASE,
    message TEXT NOT NULL, is_read INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)''')
  c.execute('''CREATE TABLE IF NOT EXISTS hr_knowledge (
    id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, body TEXT NOT NULL,
    keywords TEXT NOT NULL DEFAULT '', scope TEXT NOT NULL DEFAULT 'all',
    source_label TEXT NOT NULL DEFAULT 'Внутренняя база знаний',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP)''')
  for item in (
   ('Как оформить отпуск?', 'Для отпуска откройте раздел «Заявки», выберите «Отпуск», укажите даты и отправьте заявку. Статус и история появятся в списке. Одобрение зависит от руководителя или HR.', 'отпуск выходные даты отдых заявление отпускные оформить отпуск', 'all'),
   ('Как запросить аванс?', 'Откройте «Заявки», выберите «Аванс», укажите сумму в тенге и причину. Отслеживайте решение руководителя или HR в истории заявки. Это демонстрационный порядок, не официальный регламент выплат.', 'аванс зарплата деньги запросить получить сумма', 'all'),
   ('Как посмотреть остаток отпуска?', 'Откройте «Профиль». Остаток отпускных дней указан в карточке сотрудника. После утверждения заявки на отпуск он уменьшается на число утверждённых дней.', 'остаток отпуска дни отпускной баланс профиль', 'all'),
   ('Где посмотреть обучение?', 'В разделе «Обучение» доступны курсы вашего отдела. Подайте заявку, дождитесь одобрения, изучайте уроки и проходите тесты. Прогресс и результат отображаются в карточке курса.', 'обучение уроки курс тест прогресс тестирование пройти', 'all'),
   ('Как узнать статус заявки?', 'Откройте «Заявки». Статус бывает «На рассмотрении», «Одобрено» или «Отклонено». История фиксирует создание и решение по заявке; при смене статуса приходит уведомление.', 'статус заявка одобрено отклонено история уведомление', 'all'),
   ('Как руководителю согласовать заявку?', 'Перейдите в «Заявки» и откройте очередь на рассмотрение. Руководитель видит заявки сотрудников своего подразделения и может одобрить или отклонить их. HR управляет всеми заявками.', 'руководитель согласовать одобрить отклонить рассмотреть заявки подчинённые', 'manager'),
   ('Кто меняет данные профиля и базу знаний?', 'HR редактирует HR-профили и статьи базы знаний. Сотрудник видит собственный профиль. Руководитель работает с заявками своего подразделения.', 'hr администратор изменения профиль данные база знаний права', 'all'),
  ):
   if not c.execute('SELECT id FROM hr_knowledge WHERE title=?',(item[0],)).fetchone():
    c.execute('INSERT INTO hr_knowledge(title,body,keywords,scope,source_label) VALUES (?,?,?,?,?)',(*item,'Демонстрационный HR-регламент GPI Control'))
  # Starter courses are installed once per department/title, including on existing databases.
  starter_file=ROOT/'starter_courses.json'
  if starter_file.exists():
   for item in json.loads(starter_file.read_text(encoding='utf8')):
    exists=c.execute('SELECT 1 FROM courses WHERE department=? AND title=?',(item['department'],item['title'])).fetchone()
    if not exists:
     c.execute('INSERT INTO courses(title,description,lessons,department,created_by) VALUES (?,?,?,?,?)',
      (item['title'],item['description'],item['lessons'],item['department'],'admin'))
  quiz_file=ROOT/'starter_quizzes.json'
  if quiz_file.exists():
   for item in json.loads(quiz_file.read_text(encoding='utf8')):
    for course in c.execute('SELECT id FROM courses WHERE title=?',(item['title'],)).fetchall():
     if not c.execute('SELECT 1 FROM course_quizzes WHERE course_id=?',(course['id'],)).fetchone():
      c.execute('INSERT INTO course_quizzes(course_id,questions_json) VALUES (?,?)',(course['id'],json.dumps(item['questions'],ensure_ascii=False)))
  lesson_file=ROOT/'starter_lesson_quizzes.json'
  if lesson_file.exists():
   for item in json.loads(lesson_file.read_text(encoding='utf8')):
    for course in c.execute('SELECT id,lessons FROM courses WHERE title=? AND department=?',(item['title'],item['department'])).fetchall():
     for i,lesson in enumerate(item['lessons'][:course['lessons']],1):
      existing=c.execute('SELECT questions_json FROM lesson_quizzes WHERE course_id=? AND lesson_number=?',(course['id'],i)).fetchone()
      qs_json=json.dumps(lesson['questions'],ensure_ascii=False)
      if not existing:
       c.execute('INSERT INTO lesson_quizzes(course_id,lesson_number,title,questions_json) VALUES (?,?,?,?)',(course['id'],i,lesson['title'],qs_json))
      else:
       # Upgrade only the original one-question starter quizzes, never customized multi-question tests.
       previous=json.loads(existing['questions_json'])
       if len(previous)==1 and len(lesson['questions'])==4 and previous[0]==lesson['questions'][0]:
        c.execute('UPDATE lesson_quizzes SET title=?,questions_json=? WHERE course_id=? AND lesson_number=?',
         (lesson['title'],qs_json,course['id'],i))
  material_file=ROOT/'starter_lesson_content.json'
  if material_file.exists():
   for item in json.loads(material_file.read_text(encoding='utf8')):
    for course in c.execute('SELECT id,lessons FROM courses WHERE title=? AND department=?',(item['title'],item['department'])).fetchall():
     for i,lesson in enumerate(item['lessons'][:course['lessons']],1):
      c.execute('INSERT OR IGNORE INTO lesson_materials(course_id,lesson_number,content_json) VALUES (?,?,?)',
       (course['id'],i,json.dumps(lesson,ensure_ascii=False)))
  # Visible HR role rename; keep the internal role and login for backwards compatibility.
  c.execute("UPDATE users SET name='HR' WHERE login='admin' AND name='Администратор Системы'")
  c.execute("UPDATE hr_knowledge SET body=REPLACE(body,'HR/Администратор','HR') WHERE source_label='Демонстрационный HR-регламент GPI Control' AND title IN ('Как руководителю согласовать заявку?','Кто меняет данные профиля и базу знаний?')")
  if c.execute('SELECT id FROM state').fetchone(): return
  data=json.loads((ROOT/'seed.json').read_text(encoding='utf8'))
  for u in data.pop('users'):
   c.execute('INSERT INTO users VALUES (?,?,?,?,?,?)',(u['login'],hashpass(u['password']),u['role'],u['name'],u.get('employeeId'),u.get('department')))
  c.execute('INSERT INTO state VALUES (1,0,?)',(json.dumps(data,ensure_ascii=False),))
def public(u):
 if u is None:return None
 return dict(login=u['login'],role=u['role'],name=u['name'],**({'employeeId':u['employeeId']} if u['employeeId'] else {}),**({'department':u['department']} if u['department'] else {}))
def state(c):
 r=c.execute('SELECT rev,data FROM state').fetchone()
 d=json.loads(r['data']);d.get('settings',{}).pop('aiApiKey',None);d['users']=[public(u) for u in c.execute('SELECT * FROM users')]
 return r['rev'],d
def visible_state(full,u):
 """Expose only departmental GPI data to non-admin users.
    HR profiles/requests are never part of the shared legacy JSON state."""
 if u['role']=='admin':return copy.deepcopy(full)
 d=copy.deepcopy(full)
 if u['role']=='manager':dept=u['department']
 else:
  own=next((x for x in full['employees'] if x['id']==u['employeeId']),None)
  dept=own['department'] if own else None
 dept_ids={x['id'] for x in full['employees'] if x.get('department')==dept} if dept else set()
 d['employees']=[x for x in full['employees'] if x['id'] in dept_ids]
 d['tasks']=[x for x in full['tasks'] if x.get('employeeId') in dept_ids]
 d['notifications']=[x for x in full['notifications'] if
   u['role']=='manager' and bool(dept) and x.get('scopeDept')==dept or
   u['role']=='employee' and (x.get('scopeEmployee')==u['employeeId'] and bool(u['employeeId']) or
   x.get('scopeDept')==dept and bool(dept) and not x.get('scopeEmployee'))]
 d['rewardHistory']=[x for x in full.get('rewardHistory',[]) if x.get('employeeId') in dept_ids]
 d['users']=[x for x in full['users'] if x['login'].lower()==u['login'].lower() or
   u['role']=='manager' and x.get('employeeId') in dept_ids]
 # The shared trend aggregates from other departments are not sent to non-admin accounts.
 d['dashboardHistory']={}
 return d

def merge_visible(full,submitted,u):
 if u['role']=='admin':return copy.deepcopy(submitted)
 merged=copy.deepcopy(full)
 previous=visible_state(full,u)
 # Merge changed members without deleting anything outside this user's view.
 for key in ('employees','tasks','notifications','rewardHistory'):
  known={x['id'] for x in previous.get(key,[]) if 'id' in x}
  if key=='rewardHistory':
   continue # Non-admin roles never have permission to edit reward history.
  merged[key]=[x for x in full[key] if x['id'] not in known]+copy.deepcopy(submitted[key])
 return merged

def scoped_notifications_valid(old,new,u):
 if u['role']=='admin':return True
 before={x['id']:x for x in old['notifications']}
 for n in new['notifications']:
  if n.get('id') in before:continue
  if u['role']=='manager':
   if n.get('scopeDept')!=u['department']:return False
   if n.get('scopeEmployee') and n['scopeEmployee'] not in {x['id'] for x in old['employees']}:return False
  else:
   if n.get('scopeEmployee')!=u['employeeId']:return False
 return True

def idx(xs):return {x['id']:x for x in xs}
def diffs(a,b):
 x,y=idx(a),idx(b);return [(x.get(k),y.get(k)) for k in x.keys()|y.keys() if x.get(k)!=y.get(k)]
def authorized(old,new,u):
 role=u['role']
 if role=='admin':return True
 allowed={'employee':('tasks','notifications'),'manager':('employees','tasks','notifications','users')}.get(role,())
 if any(old.get(k)!=new.get(k) for k in old.keys()|new.keys() if k not in allowed):return False
 if role=='employee':
  for a,b in diffs(old['tasks'],new['tasks']):
   if not a or not b or a.get('employeeId')!=u['employeeId']:return False
   if any(a.get(k)!=b.get(k) for k in a.keys()|b.keys() if k not in ('actual','completedAt')):return False
 if role=='manager':
  for k in ('employees','tasks'):
   for a,b in diffs(old[k],new[k]):
    if any(v and v.get('department')!=u['department'] for v in (a,b)):return False
 return True
def check_users(old,new,u):
 a={x.get('employeeId') or 'login:'+x['login']:x for x in old['users']}
 b={x.get('employeeId') or 'login:'+x['login']:x for x in new['users']}
 if len(b)!=len(new['users']):return False
 employees={x['id']:x for x in old['employees']+new['employees']}
 for k in a.keys()|b.keys():
  before,after=a.get(k),b.get(k)
  if before==after:continue
  if u['role']=='employee' or before and before['role']!='employee' or after and after.get('role')!='employee':return False
  empid=(after or before).get('employeeId')
  if not empid or empid not in employees:return False
  if u['role']=='manager' and employees[empid]['department']!=u['department']:return False
  if after:
   if not isinstance(after.get('login'),str) or not after['login'].strip() or len(after['login'])>80:return False
   if not before and (not isinstance(after.get('password'),str) or len(after['password'])<6):return False
   if 'password' in after and (not isinstance(after['password'],str) or len(after['password'])<6):return False
 return True
def sync_users(c,old,new):
 a={x.get('employeeId') or 'login:'+x['login']:x for x in old['users']}
 b={x.get('employeeId') or 'login:'+x['login']:x for x in new['users']}
 for k,v in a.items():
  w=b.get(k)
  if not w:c.execute('DELETE FROM users WHERE login=?',(v['login'],))
  elif w!=v:
   if 'password' in w:c.execute('UPDATE users SET login=?,name=?,passhash=? WHERE login=?',(w['login'],w.get('name',''),hashpass(w['password']),v['login']))
   else:c.execute('UPDATE users SET login=?,name=? WHERE login=?',(w['login'],w.get('name',''),v['login']))
 for k,w in b.items():
  if k not in a:c.execute('INSERT INTO users VALUES (?,?,?,?,?,?)',(w['login'],hashpass(w['password']),'employee',w.get('name',''),w.get('employeeId'),None))
TASK_LATE_PENALTY=10  # virtual GPI score points, not real money or salary

def task_scope(u,task,full):
 if not task:return False
 if u['role']=='admin':return True
 if u['role']=='manager':return task.get('department')==u['department']
 return task.get('employeeId')==u['employeeId']

def task_assignee(c,task):
 row=c.execute('SELECT login FROM users WHERE employeeId=? AND role=?',(task.get('employeeId'),'employee')).fetchone()
 return row['login'] if row else None

def sync_task_penalties(c,full):
 today=date.today()
 for t in full.get('tasks',[]):
  tid=str(t.get('id',''))
  try: deadline=date.fromisoformat(str(t.get('deadline',''))[:10])
  except ValueError:continue
  if not tid or not t.get('employeeId') or deadline>=today:continue
  # Respect historical completed tasks from databases predating approval workflow.
  completed=str(t.get('completedAt') or '')[:10]
  if completed and completed<=str(deadline) and int(t.get('actual') or 0)>=int(t.get('plan') or 1):continue
  # Only count a missed deadline if work was not approved by that day.
  flow=c.execute('SELECT approved_at FROM task_workflows WHERE task_id=?',(tid,)).fetchone()
  approved=str(flow['approved_at'] or '')[:10] if flow else ''
  if approved and approved<=str(deadline):continue
  exists=c.execute('SELECT 1 FROM task_penalties WHERE task_id=?',(tid,)).fetchone()
  if exists:continue
  c.execute('INSERT INTO task_penalties(task_id,employee_id,amount,reason) VALUES (?,?,?,?)',
   (tid,t['employeeId'],TASK_LATE_PENALTY,'Задание просрочено: '+str(t.get('title',''))[:120]))
  c.execute('INSERT INTO task_audit(task_id,actor,action,details) VALUES (?,?,?,?)',
   (tid,'system','penalty',f'-{TASK_LATE_PENALTY} GPI за просрочку'))
  assigned=task_assignee(c,t)
  if assigned:hr_notify(c,assigned,f'Штраф -{TASK_LATE_PENALTY} GPI: просрочено задание «{t.get("title","")}».')

def task_workflow_data(c,u,full):
 sync_task_penalties(c,full)
 tasks={str(t['id']):t for t in full.get('tasks',[]) if task_scope(u,t,full)}
 rows=[dict(r) for r in c.execute('SELECT * FROM task_workflows') if r['task_id'] in tasks]
 allowed_empids={e['id'] for e in full.get('employees',[]) if u['role']=='admin' or (u['role']=='manager' and e.get('department')==u['department']) or (u['role']=='employee' and e['id']==u['employeeId'])}
 penalties=[dict(r) for r in c.execute('SELECT * FROM task_penalties') if r['employee_id'] in allowed_empids]
 audit=[dict(r) for r in c.execute('SELECT * FROM task_audit ORDER BY id DESC LIMIT 200') if r['task_id'] in tasks]
 return {'workflows':rows,'penalties':penalties,'audit':audit,'penalty_size':TASK_LATE_PENALTY}

def hr_profile(c,login):
 row=c.execute('SELECT * FROM hr_profiles WHERE login=?',(login,)).fetchone()
 if row:return dict(row)
 user=c.execute('SELECT * FROM users WHERE login=?',(login,)).fetchone()
 if user is None:return None
 _,d=state(c)
 emp=next((e for e in d.get('employees',[]) if e.get('id')==user['employeeId']),None)
 dept=(emp or {}).get('department') or user['department'] or ''
 position=(emp or {}).get('position') or ('Руководитель' if user['role']=='manager' else 'HR' if user['role']=='admin' else 'Сотрудник')
 supervisor='manager' if user['role']=='employee' and dept=='Продажи' else 'admin' if user['role']=='manager' else ''
 c.execute('INSERT OR IGNORE INTO hr_profiles(login,company,position,department,supervisor,hire_date,vacation_balance) VALUES (?,?,?,?,?,?,?)',
  (login,d.get('settings',{}).get('companyName','GPI Demo'),position,dept,supervisor,'2025-09-01',24))
 return dict(c.execute('SELECT * FROM hr_profiles WHERE login=?',(login,)).fetchone())

def hr_department(c,u):
 return (hr_profile(c,u['login']) or {}).get('department','')

def hr_can_review(c,u,target):
 if target['login'].lower()==u['login'].lower():return False
 if u['role']=='admin':return True
 if u['role']!='manager' or target['role']!='employee':return False
 return bool(hr_department(c,u)) and hr_department(c,u)==hr_department(c,target)

def hr_notify(c,login,message):
 c.execute('INSERT INTO hr_notices(recipient,message) VALUES (?,?)',(login,message[:350]))

def hr_visible_article(u,article,dept):
 scope=article['scope']
 return u['role']=='admin' or scope=='all' or scope=='manager' and u['role']=='manager' or scope.startswith('dept:') and scope[5:]==dept

def kb_words(q):
 ignore={'как','где','что','можно','мне','нужно','хочу','узнать','для','меня','мои','мой','моя','по','из','на','от','это','или','и','а','в','с','у','о','подскажите','пожалуйста','есть','ли','кто','если','при','могу'}
 return {w for w in re.findall(r'[а-яёa-z0-9]+',q.lower()) if len(w)>=3 and w not in ignore}

def knowledge_answer(c,u,question):
 dept=hr_department(c,u)
 words=kb_words(question)
 best=None;score=0
 if not words:return None
 for row in c.execute('SELECT * FROM hr_knowledge ORDER BY id'):
  if not hr_visible_article(u,row,dept):continue
  title=kb_words(row['title']);tags=kb_words(row['keywords']);body=kb_words(row['body'])
  matched_title=words & title;matched_tags=words & tags
  points=6*len(matched_title)+4*len(matched_tags)+len(words & body)
  if (matched_title or matched_tags) and points>score:
   best,score=row,points
 if not best or score<4:return None
 return {'answer':best['body'][:900], 'source': '/kb/article/'+str(best['id']),
         'source_label':best['source_label']+' — '+best['title'], 'knowledge_id':best['id']}

def hr_request_public(c,row):
 result=dict(row)
 u=c.execute('SELECT name FROM users WHERE login=?',(row['login'],)).fetchone()
 result['employee_name']=u['name'] if u else row['login']
 return result

def hr_view_request(c,u,row):
 if row['login'].lower()==u['login'].lower() or u['role']=='admin':return True
 target=c.execute('SELECT * FROM users WHERE login=?',(row['login'],)).fetchone()
 return bool(target) and hr_can_review(c,u,target)

def training_notify(c, login, message):
 c.execute('INSERT INTO training_events(recipient,message) VALUES (?,?)',(login,message[:300]))
def training_manage(u,course):
 return u['role']=='admin' or (u['role']=='manager' and course['department']==u['department'])
def training_visible(u,course):
 return course['department']=='Все' or u['role']=='admin' or course['department']==u['department'] or (u['role']=='employee' and u['employeeId'] is not None and course['department']==employee_department(u))
def employee_department(u):
 with conn() as c:
  _,d=state(c)
 return next((e.get('department') for e in d['employees'] if e['id']==u['employeeId']),None)
AI_INSTRUCTIONS = """Ты AI Jana — ИИ внутри GPI Control. Отвечай на языке пользователя.
Отвечай кратко, конкретно и по существу, без вступлений и воды.
Не выдумывай факты, числа, источники, даты и события. Если не знаешь, скажи прямо: «Я не знаю».
Если факт нельзя достоверно проверить по предоставленной информации, скажи «Не могу подтвердить».
Не утверждай, что у тебя есть доступ к данным GPI Control, интернету или файлам, если они не были предоставлены.
Не выполняй административные действия. Не раскрывай личные данные третьих лиц.
Если вопрос требует актуальных данных, объясни, что без проверки они могут быть устаревшими.
"""
# Only a loopback Ollama server may receive internal AI requests. This is NOT a
# generic URL proxy and no LAN client can choose the AI endpoint or a secret.
def ollama_url():
 raw=os.environ.get('GPI_OLLAMA_URL','http://127.0.0.1:11434').strip().rstrip('/')
 parsed=urlsplit(raw)
 host=parsed.hostname
 try:
  allowed=host=='localhost' or (host is not None and ipaddress.ip_address(host).is_loopback)
 except ValueError:
  allowed=False
 try: port=parsed.port
 except ValueError: port=None
 if (parsed.scheme!='http' or not allowed or not port or parsed.username or parsed.password
     or parsed.path or parsed.query or parsed.fragment):
  raise RuntimeError('GPI_OLLAMA_URL должен указывать на локальный HTTP-сервер (127.0.0.1 или localhost) с портом.')
 return raw

# Explicitly bypass HTTP proxies even when the machine has an HTTP_PROXY setting.
OLLAMA_HTTP=urllib.request.build_opener(urllib.request.ProxyHandler({}))
AI_SLOTS=threading.BoundedSemaphore(2)
def ollama_request(path,payload=None,timeout=12):
 headers={'Content-Type':'application/json'}
 data=None if payload is None else json.dumps(payload,ensure_ascii=False).encode('utf-8')
 request=urllib.request.Request(ollama_url()+path,data=data,headers=headers,
  method='POST' if payload is not None else 'GET')
 try:
  with OLLAMA_HTTP.open(request,timeout=timeout) as response:
   raw=response.read(262145)
   if len(raw)>262144:raise RuntimeError('Слишком большой ответ локальной модели.')
   return json.loads(raw)
 except urllib.error.HTTPError as e:
  if e.code==404:raise RuntimeError('Модель не найдена в Ollama. Установите её и проверьте название.')
  raise RuntimeError('Локальный ИИ вернул HTTP '+str(e.code)+'.')
 except (urllib.error.URLError,TimeoutError,ConnectionError):
  raise RuntimeError('Локальный ИИ недоступен. Запустите Ollama на основном компьютере.')
 except (UnicodeDecodeError,json.JSONDecodeError):
  raise RuntimeError('Локальный ИИ вернул некорректный ответ.')

def installed_models():
 result=ollama_request('/api/tags',timeout=6)
 if not isinstance(result,dict) or not isinstance(result.get('models'),list):
  raise RuntimeError('Не удалось получить список моделей Ollama.')
 return sorted({m['name'] for m in result['models'] if isinstance(m,dict)
  and isinstance(m.get('name'),str) and 0<len(m['name'])<160})

def selected_model():
 with conn() as c:
  row=c.execute('SELECT model FROM ai_settings WHERE id=1').fetchone()
 return row['model'] if row else ''

def ask_local_ai(messages,model):
 if not model:raise RuntimeError('HR ещё не выбрал локальную ИИ-модель в настройках.')
 if not AI_SLOTS.acquire(blocking=False):raise RuntimeError('ИИ занят двумя запросами. Попробуйте через минуту.')
 try:
  body={'model':model,'stream':False,'keep_alive':'5m',
   'messages':[{'role':'system','content':AI_INSTRUCTIONS}]+messages,
   'options':{'temperature':0.2,'num_predict':450}}
  result=ollama_request('/api/chat',body,timeout=150)
  answer=result.get('message',{}).get('content') if isinstance(result,dict) else None
  if not isinstance(answer,str) or not answer.strip():
   raise RuntimeError('Локальная модель не вернула текст ответа.')
  return answer.strip()
 finally:AI_SLOTS.release()

class Handler(BaseHTTPRequestHandler):
 def reply(self,status,value,cookie=None):
  body=json.dumps(value,ensure_ascii=False).encode()
  self.send_response(status);self.send_header('Content-Type','application/json; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff');self.send_header('Referrer-Policy','no-referrer')
  if cookie:self.send_header('Set-Cookie',cookie)
  self.send_header('Content-Length',str(len(body)));self.end_headers();self.wfile.write(body)
 def user(self):
  try:
   cookies=SimpleCookie();cookies.load(self.headers.get('Cookie',''));token=cookies.get('gpi_session').value
   entry=SESSIONS.get(token)
   if not entry or entry[1]<time.time():return None
   with conn() as c:return c.execute('SELECT * FROM users WHERE login=?',(entry[0],)).fetchone()
  except (AttributeError,KeyError):return None
 def do_GET(self):
  path=urlsplit(self.path).path
  if path.startswith('/kb/article/'):
   u=self.user()
   if not u:return self.reply(401,{'error':'Сначала войдите в GPI Control'})
   try:article_id=int(path.rsplit('/',1)[-1])
   except ValueError:return self.send_error(404)
   with LOCK,conn() as c:
    article=c.execute('SELECT * FROM hr_knowledge WHERE id=?',(article_id,)).fetchone()
    if not article or not hr_visible_article(u,article,hr_department(c,u)):return self.send_error(404)
    title=html.escape(article['title']);body=html.escape(article['body']);source=html.escape(article['source_label'])
   page=('<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">'
    '<title>'+title+' — GPI Control</title><style>body{font:16px/1.65 system-ui;margin:0;background:#f4faf6;color:#183321}'
    'main{max-width:740px;margin:45px auto;padding:32px;background:white;border-radius:20px;border:1px solid #d5e7dc}'
    'a{color:#087126}p{white-space:pre-wrap}</style><main><a href="/">← GPI Control</a><h1>'+title+'</h1><p>'+body+'</p>'
    '<small>Источник: '+source+'</small></main></html>').encode('utf8')
   self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8')
   self.send_header('Content-Security-Policy',"default-src 'none'; style-src 'unsafe-inline'")
   self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(page)))
   self.end_headers();self.wfile.write(page);return
  if path=='/api/tasks/workflow':
   u=self.user()
   if not u:return self.reply(401,{'error':'Войдите в систему'})
   with LOCK,conn() as c:
    _,full=state(c)
    data=task_workflow_data(c,u,full)
    c.commit()
   return self.reply(200,data)
  if path=='/api/state':
   u=self.user()
   if not u:return self.reply(401,{'error':'Войдите в систему'})
   with LOCK,conn() as c:r,d=state(c)
   return self.reply(200,{'revision':r,'data':visible_state(d,u),'user':public(u)})
  if path=='/api/me':return self.reply(200,{'user':public(self.user())})
  if path=='/api/hr/dashboard':
   u=self.user()
   if not u:return self.reply(401,{'error':'Войдите в систему'})
   with LOCK,conn() as c:
    profile=hr_profile(c,u['login'])
    requests=[hr_request_public(c,r) for r in c.execute('SELECT * FROM hr_requests ORDER BY id DESC LIMIT 200') if hr_view_request(c,u,r)]
    request_ids={r['id'] for r in requests}
    history=[dict(x) for x in c.execute('SELECT request_id,actor,event,created_at FROM hr_request_history ORDER BY id DESC') if x['request_id'] in request_ids]
    notices=[dict(n) for n in c.execute('SELECT id,message,is_read,created_at FROM hr_notices WHERE recipient=? ORDER BY id DESC LIMIT 80',(u['login'],))]
    training_notices=[dict(n) for n in c.execute('SELECT id,message,is_read,created_at FROM training_events WHERE recipient=? ORDER BY id DESC LIMIT 80',(u['login'],))]
    articles=[{'id':r['id'],'title':r['title'],'scope':r['scope'],'source_label':r['source_label'],
     'body':r['body'] if u['role']=='admin' else '',
     'keywords':r['keywords'] if u['role']=='admin' else ''}
     for r in c.execute('SELECT * FROM hr_knowledge ORDER BY id DESC') if hr_visible_article(u,r,profile['department'])]
   return self.reply(200,{'profile':profile,'requests':requests,'history':history,'notices':notices,
     'training_notices':training_notices,'articles':articles})
  if path=='/api/hr/profile':
   u=self.user()
   if not u:return self.reply(401,{'error':'Войдите в систему'})
   login=parse_qs(urlsplit(self.path).query).get('login',[u['login']])[0]
   if login.lower()!=u['login'].lower() and u['role']!='admin':return self.reply(403,{'error':'Нет доступа к чужому профилю'})
   with LOCK,conn() as c:
    profile=hr_profile(c,login)
    if profile is None:return self.reply(404,{'error':'Сотрудник не найден'})
   return self.reply(200,{'profile':profile})
  if path=='/api/hr/users':
   u=self.user()
   if not u:return self.reply(401,{'error':'Войдите в систему'})
   if u['role']!='admin':return self.reply(403,{'error':'Нет прав'})
   with LOCK,conn() as c:
    users=[dict(login=x['login'],name=x['name'],role=x['role']) for x in c.execute('SELECT * FROM users ORDER BY name')]
   return self.reply(200,{'users':users})
  if path=='/api/ai/config':
   u=self.user()
   if not u:return self.reply(401,{'error':'Войдите в систему'})
   if u['role']!='admin':return self.reply(403,{'error':'Настройки модели доступны только HR'})
   return self.reply(200,{'model':selected_model(),'mode':'local','endpoint':'127.0.0.1 (основной компьютер)'})
  if path=='/api/ai/models':
   u=self.user()
   if not u:return self.reply(401,{'error':'Войдите в систему'})
   if u['role']!='admin':return self.reply(403,{'error':'Нет прав'})
   try: models=installed_models()
   except RuntimeError as e:return self.reply(503,{'error':str(e)})
   return self.reply(200,{'models':models,'current':selected_model()})

  if path=='/api/training':
   u=self.user()
   if not u:return self.reply(401,{'error':'Войдите в систему'})
   with LOCK,conn() as c:
    courses=[dict(x) for x in c.execute('SELECT * FROM courses ORDER BY id DESC')]
    enrollment=[dict(x) for x in c.execute('SELECT * FROM enrollments')]
    notices=[dict(x) for x in c.execute('SELECT * FROM training_events WHERE recipient=? ORDER BY id DESC LIMIT 40',(u['login'],))]
    quiz_counts={r['course_id']:r['count'] for r in c.execute('SELECT course_id,COUNT(*) AS count FROM course_quizzes, json_each(course_quizzes.questions_json) GROUP BY course_id')}
    quiz_results=[dict(r) for r in c.execute('SELECT course_id,score,total,submitted_at FROM quiz_results WHERE login=?',(u['login'],))]
    lesson_titles=[dict(r) for r in c.execute('SELECT q.course_id,q.lesson_number,q.title, CASE WHEN m.content_json IS NOT NULL THEN 1 ELSE 0 END AS has_content, json_array_length(q.questions_json) AS question_count FROM lesson_quizzes q LEFT JOIN lesson_materials m ON m.course_id=q.course_id AND m.lesson_number=q.lesson_number JOIN courses c ON c.id=q.course_id AND q.lesson_number<=c.lessons')]
    lesson_results=[dict(r) for r in c.execute('SELECT course_id,lesson_number,score,total,submitted_at FROM lesson_quiz_results WHERE login=?',(u['login'],))]


   dept=employee_department(u) if u['role']=='employee' else u['department'] if u['role']=='manager' else None
   courses=[x for x in courses if u['role']=='admin' or x['department']=='Все' or x['department']==dept]
   ids={x['id'] for x in courses}
   enrollment=[x for x in enrollment if x['course_id'] in ids and (u['role']=='admin' or (u['role']=='manager' and next((c['department'] for c in courses if c['id']==x['course_id']),None)==u['department']) or x['login'].lower()==u['login'].lower())]
   return self.reply(200,{'courses':courses,'enrollments':enrollment,'notices':notices,'quiz_counts':{str(k):v for k,v in quiz_counts.items() if k in ids},'quiz_results':[r for r in quiz_results if r['course_id'] in ids],'lesson_titles':[r for r in lesson_titles if r['course_id'] in ids],'lesson_results':[r for r in lesson_results if r['course_id'] in ids]})
  if path=='/api/lesson/content':
   u=self.user()
   if not u:return self.reply(401,{'error':'Войдите в систему'})
   try:
    args=parse_qs(urlsplit(self.path).query)
    course_id=int(args.get('course_id',['0'])[0]);lesson_number=int(args.get('lesson_number',['0'])[0])
   except (TypeError,ValueError):return self.reply(400,{'error':'Неверный урок'})
   with LOCK,conn() as c:
    course=c.execute('SELECT * FROM courses WHERE id=?',(course_id,)).fetchone()
    if not course or not training_visible(u,course) or not 1<=lesson_number<=course['lessons']:
     return self.reply(404,{'error':'Урок не найден'})
    enrollment=c.execute('SELECT status FROM enrollments WHERE course_id=? AND login=?',(course_id,u['login'])).fetchone()
    if not enrollment or enrollment['status'] not in ('approved','completed'):
     return self.reply(403,{'error':'Сначала дождитесь одобрения заявки'})
    lesson=c.execute('SELECT content_json FROM lesson_materials WHERE course_id=? AND lesson_number=?',(course_id,lesson_number)).fetchone()
    if not lesson:return self.reply(404,{'error':'Материал урока не найден'})
    return self.reply(200,{'course_id':course_id,'course_title':course['title'],
      'lesson_number':lesson_number,'total_lessons':course['lessons'],'lesson':json.loads(lesson['content_json'])})
  if path=='/api/lesson-quiz':
   u=self.user()
   if not u:return self.reply(401,{'error':'Войдите в систему'})
   try:
    args=parse_qs(urlsplit(self.path).query)
    course_id=int(args.get('course_id',['0'])[0])
    lesson_number=int(args.get('lesson_number',['0'])[0])
   except (TypeError,ValueError):return self.reply(400,{'error':'Неверный урок'})
   with LOCK,conn() as c:
    course=c.execute('SELECT * FROM courses WHERE id=?',(course_id,)).fetchone()
    if not course or not training_visible(u,course):return self.reply(404,{'error':'Урок не найден'})
    enrollment=c.execute('SELECT status FROM enrollments WHERE course_id=? AND login=?',(course_id,u['login'])).fetchone()
    if not enrollment or enrollment['status'] not in ('approved','completed'):
     return self.reply(403,{'error':'Нужна одобренная заявка на курс'})
    row=c.execute('SELECT * FROM lesson_quizzes WHERE course_id=? AND lesson_number=?',(course_id,lesson_number)).fetchone()
    if not row:return self.reply(404,{'error':'Тест урока не найден'})
    qs=json.loads(row['questions_json'])
    return self.reply(200,{'course_id':course_id,'lesson_number':lesson_number,'title':row['title'],
      'questions':[{'question':q['question'],'options':q['options']} for q in qs]})
  if path.startswith('/api/quiz/'):
   u=self.user()
   if not u:return self.reply(401,{'error':'Войдите в систему'})
   try: course_id=int(parse_qs(urlsplit(self.path).query).get('course_id',['0'])[0])
   except (TypeError,ValueError):return self.reply(400,{'error':'Неверный курс'})
   with LOCK,conn() as c:
    course=c.execute('SELECT * FROM courses WHERE id=?',(course_id,)).fetchone()
    if not course or not training_visible(u,course):return self.reply(404,{'error':'Тест не найден'})
    quiz=c.execute('SELECT questions_json FROM course_quizzes WHERE course_id=?',(course_id,)).fetchone()
    if not quiz:return self.reply(404,{'error':'Для курса нет теста'})
    questions=json.loads(quiz['questions_json'])
    enrollment=c.execute('SELECT status FROM enrollments WHERE course_id=? AND login=?',(course_id,u['login'])).fetchone()
    if not enrollment or enrollment['status'] not in ('approved','completed'):
     return self.reply(403,{'error':'Для прохождения теста нужна одобренная заявка'})
    safe=[{'question':q['question'],'options':q['options']} for q in questions]
    return self.reply(200,{'course_id':course_id,'title':course['title'],'questions':safe})
  if path=='/api/chat/people':
   u=self.user()
   if not u:return self.reply(401,{'error':'Войдите в систему'})
   with conn() as c:
    people=[public(x) for x in c.execute('SELECT * FROM users WHERE login != ? COLLATE NOCASE ORDER BY name',(u['login'],))]
   return self.reply(200,{'people':people})
  if path=='/api/chat/messages':
   u=self.user()
   if not u:return self.reply(401,{'error':'Войдите в систему'})
   peer=parse_qs(urlsplit(self.path).query).get('peer',[''])[0]
   if not peer:return self.reply(400,{'error':'Выберите собеседника'})
   with conn() as c:
    exists=c.execute('SELECT login FROM users WHERE login=?',(peer,)).fetchone()
    if not exists:return self.reply(404,{'error':'Сотрудник не найден'})
    messages=[dict(x) for x in c.execute('SELECT id,sender,recipient,body,created_at FROM direct_messages WHERE (sender=? AND recipient=?) OR (sender=? AND recipient=?) ORDER BY id DESC LIMIT 150',(u['login'],peer,peer,u['login']))]
   messages.reverse()
   return self.reply(200,{'messages':messages})
  if path not in ('/','/index.html'):return self.send_error(404)
  raw=(ROOT/'index.html').read_bytes();self.send_response(200);self.send_header('Content-Type','text/html; charset=utf-8');self.send_header('Cache-Control','no-store');self.send_header('Content-Length',str(len(raw)));self.end_headers();self.wfile.write(raw)
 def do_POST(self):
  path=urlsplit(self.path).path
  origin=self.headers.get('Origin')
  if origin and urlsplit(origin).netloc!=self.headers.get('Host'):return self.reply(403,{'error':'Неверный источник запроса'})
  try:
   n=int(self.headers.get('Content-Length','0'))
   if not 0<n<3000000:raise ValueError()
   p=json.loads(self.rfile.read(n))
  except (ValueError,TypeError):return self.reply(400,{'error':'Неверный запрос'})
  if path=='/api/tasks/action':
   u=self.user()
   if not u:return self.reply(401,{'error':'Войдите в систему'})
   task_id=str(p.get('task_id',''))[:90];action=str(p.get('action',''))
   if action not in ('accept','progress','submit','approve','reject') or not task_id:
    return self.reply(400,{'error':'Неверное действие'})
   with LOCK,conn() as c:
    rev,full=state(c)
    task=next((x for x in full.get('tasks',[]) if str(x.get('id'))==task_id),None)
    if not task or not task_scope(u,task,full):return self.reply(403,{'error':'Нет доступа к заданию'})
    assignee=task_assignee(c,task)
    is_assignee=u['role']=='employee' and task.get('employeeId')==u['employeeId'] and assignee==u['login']
    is_reviewer=u['role']=='admin' or (u['role']=='manager' and task.get('department')==u['department'])
    row=c.execute('SELECT * FROM task_workflows WHERE task_id=?',(task_id,)).fetchone()
    status=row['status'] if row else 'assigned'
    proposed=int(row['proposed']) if row else 0
    if action in ('accept','progress','submit') and not is_assignee:return self.reply(403,{'error':'Только исполнитель может принять или сдать задание'})
    if action in ('approve','reject') and not is_reviewer:return self.reply(403,{'error':'Подтверждает только руководитель или HR'})
    if action=='accept':
     if status!='assigned':return self.reply(409,{'error':'Задание уже принято'})
     status='accepted';details='Исполнитель принял задание'
    elif action=='progress':
     if status not in ('accepted','working','rejected','approved') or (status=='approved' and int(task.get('actual',0))>=int(task.get('plan',0))):return self.reply(409,{'error':'Задание уже завершено либо не принято'})
     try:proposed=int(p.get('amount'))
     except (ValueError,TypeError):return self.reply(400,{'error':'Укажите целое число'})
     if proposed<int(task.get('actual') or 0) or proposed>1000000:return self.reply(400,{'error':'Заявленный прогресс не может быть меньше подтверждённого'})
     status='working';details=f'Заявленный объём работы: {proposed}'
    elif action=='submit':
     if status not in ('accepted','working','rejected'):return self.reply(409,{'error':'Сначала примите задание'})
     if proposed<=0:return self.reply(400,{'error':'Укажите объём выполненной работы'})
     status='submitted';details=f'Отправлено на проверку: {proposed}'
    elif action=='reject':
     if status!='submitted':return self.reply(409,{'error':'Задание не отправлено на проверку'})
     status='rejected';details='Возвращено на доработку'
    else:
     if status!='submitted':return self.reply(409,{'error':'Задание не отправлено на проверку'})
     status='approved';details=f'Подтверждено: {proposed}'
     task['actual']=proposed
     if proposed>=max(1,int(task.get('plan') or 1)):task['completedAt']=date.today().isoformat()
     else:task['completedAt']=None
     full.pop('users',None)
     c.execute('UPDATE state SET rev=?,data=? WHERE id=1',(rev+1,json.dumps(full,ensure_ascii=False)))
    note=str(p.get('note','')).strip()[:600]
    c.execute('''INSERT INTO task_workflows(task_id,status,proposed,note,employee_login,reviewer,updated_at,approved_at)
     VALUES(?,?,?,?,?, ?,CURRENT_TIMESTAMP,?) ON CONFLICT(task_id) DO UPDATE SET
     status=excluded.status,proposed=excluded.proposed,note=excluded.note,reviewer=excluded.reviewer,
     updated_at=CURRENT_TIMESTAMP,approved_at=excluded.approved_at''',
     (task_id,status,proposed,note,assignee or '',u['login'] if is_reviewer else '',date.today().isoformat() if action=='approve' else (row['approved_at'] if row else '')))
    c.execute('INSERT INTO task_audit(task_id,actor,action,details) VALUES (?,?,?,?)',(task_id,u['login'],action,details+((': '+note) if note else '')))
    if is_reviewer and assignee:hr_notify(c,assignee,f'Задание «{task["title"]}»: '+('подтверждено' if action=='approve' else 'возвращено на доработку'))
    if action=='submit':
     for reviewer in c.execute('SELECT login FROM users WHERE role=? OR (role=? AND department=?)',('admin','manager',task['department'])):
      hr_notify(c,reviewer['login'],f'На проверку: «{task["title"]}» от {u["login"]}')
    sync_task_penalties(c,full)
    c.commit()
   return self.reply(200,{'ok':True,'status':status,'proposed':proposed})
  if path=='/api/hr/request/create':
   u=self.user()
   if not u:return self.reply(401,{'error':'Войдите в систему'})
   kind=p.get('kind');comment=p.get('comment','')
   if kind not in ('vacation','advance') or not isinstance(comment,str) or len(comment)>500:
    return self.reply(400,{'error':'Неверный тип заявки или комментарий'})
   start=end=None;days=amount=0
   if kind=='vacation':
    try:
     start=date.fromisoformat(p.get('start_date',''));end=date.fromisoformat(p.get('end_date',''))
     days=(end-start).days+1
    except (TypeError,ValueError):return self.reply(400,{'error':'Укажите правильные даты отпуска'})
    if not 1<=days<=30 or start<date.today():return self.reply(400,{'error':'Отпуск должен быть в будущем и не длиннее 30 календарных дней'})
   else:
    try:amount=int(p.get('amount'))
    except (TypeError,ValueError):return self.reply(400,{'error':'Укажите сумму аванса'})
    if isinstance(p.get('amount'),bool) or not 1<=amount<=10000000:return self.reply(400,{'error':'Сумма должна быть от 1 до 10 000 000 ₸'})
   with LOCK,conn() as c:
    profile=hr_profile(c,u['login'])
    if kind=='vacation' and days>profile['vacation_balance']:
     return self.reply(400,{'error':'Дней отпуска больше, чем остаток'})
    cursor=c.execute('INSERT INTO hr_requests(login,kind,start_date,end_date,days,amount,comment) VALUES (?,?,?,?,?,?,?)',
      (u['login'],kind,start.isoformat() if start else None,end.isoformat() if end else None,days,amount,comment.strip()))
    rid=cursor.lastrowid
    c.execute('INSERT INTO hr_request_history(request_id,actor,event) VALUES (?,?,?)',(rid,u['login'],'Создана заявка'))
    hr_notify(c,u['login'],'Заявка №'+str(rid)+' отправлена на рассмотрение')
    for approver in c.execute('SELECT * FROM users WHERE role IN ("admin","manager")'):
     if hr_can_review(c,approver,u):
      hr_notify(c,approver['login'],'Новая '+('заявка на отпуск' if kind=='vacation' else 'заявка на аванс')+' №'+str(rid)+' от '+u['name'])
    c.commit()
   return self.reply(200,{'ok':True,'id':rid})
  if path=='/api/hr/request/review':
   u=self.user()
   if not u:return self.reply(401,{'error':'Войдите в систему'})
   try:rid=int(p.get('request_id'))
   except (ValueError,TypeError):return self.reply(400,{'error':'Неверная заявка'})
   decision=p.get('status')
   if decision not in ('approved','rejected'):return self.reply(400,{'error':'Выберите решение'})
   with LOCK,conn() as c:
    row=c.execute('SELECT * FROM hr_requests WHERE id=?',(rid,)).fetchone()
    if not row:return self.reply(404,{'error':'Заявка не найдена'})
    target=c.execute('SELECT * FROM users WHERE login=?',(row['login'],)).fetchone()
    if not target or not hr_can_review(c,u,target):return self.reply(403,{'error':'Нет прав на эту заявку'})
    if row['status']!='pending':return self.reply(409,{'error':'Заявка уже рассмотрена'})
    if decision=='approved' and row['kind']=='vacation':
     profile=hr_profile(c,row['login'])
     if row['days']>profile['vacation_balance']:return self.reply(409,{'error':'Недостаточно отпускных дней'})
     c.execute('UPDATE hr_profiles SET vacation_balance=vacation_balance-? WHERE login=?',(row['days'],row['login']))
    c.execute('UPDATE hr_requests SET status=?,reviewer=?,updated_at=CURRENT_TIMESTAMP WHERE id=?',(decision,u['login'],rid))
    c.execute('INSERT INTO hr_request_history(request_id,actor,event) VALUES (?,?,?)',
      (rid,u['login'],'Заявка одобрена' if decision=='approved' else 'Заявка отклонена'))
    hr_notify(c,row['login'],'Заявка №'+str(rid)+' '+('одобрена' if decision=='approved' else 'отклонена'))
    c.commit()
   return self.reply(200,{'ok':True})
  if path=='/api/hr/profile/save':
   u=self.user()
   if not u:return self.reply(401,{'error':'Войдите в систему'})
   if u['role']!='admin':return self.reply(403,{'error':'Профили редактирует только HR'})
   login=p.get('login');payload=p.get('profile')
   if not isinstance(login,str) or not isinstance(payload,dict):return self.reply(400,{'error':'Неверный профиль'})
   fields=['company','position','department','supervisor','hire_date']
   if any(not isinstance(payload.get(k),str) or len(payload[k])>120 for k in fields):return self.reply(400,{'error':'Проверьте текстовые поля'})
   try:
    balance=int(payload.get('vacation_balance'))
    if payload['hire_date']:date.fromisoformat(payload['hire_date'])
   except (ValueError,TypeError):return self.reply(400,{'error':'Проверьте дату и остаток отпуска'})
   if not 0<=balance<=365:return self.reply(400,{'error':'Неверный остаток отпуска'})
   with LOCK,conn() as c:
    if not hr_profile(c,login):return self.reply(404,{'error':'Сотрудник не найден'})
    c.execute('UPDATE hr_profiles SET company=?,position=?,department=?,supervisor=?,hire_date=?,vacation_balance=? WHERE login=?',
     (*[payload[k].strip() for k in fields],balance,login))
    hr_notify(c,login,'HR-профиль обновлён сотрудником HR')
    c.commit()
   return self.reply(200,{'ok':True})
  if path=='/api/hr/knowledge/save':
   u=self.user()
   if not u:return self.reply(401,{'error':'Войдите в систему'})
   if u['role']!='admin':return self.reply(403,{'error':'Редактировать базу знаний может только HR'})
   title=p.get('title');body=p.get('body');keywords=p.get('keywords','');scope=p.get('scope','all')
   if not all(isinstance(x,str) for x in (title,body,keywords,scope)) or not 3<=len(title.strip())<=120 or not 5<=len(body.strip())<=3000 or len(keywords)>500:
    return self.reply(400,{'error':'Проверьте название, текст и ключевые слова'})
   if scope not in ('all','manager','admin') and scope not in ('dept:Продажи','dept:Маркетинг','dept:Поддержка','dept:IT'):
    return self.reply(400,{'error':'Недопустимая область видимости'})
   with LOCK,conn() as c:
    if p.get('id'):
     try:article_id=int(p['id'])
     except (TypeError,ValueError):return self.reply(400,{'error':'Неверный ID статьи'})
     c.execute('UPDATE hr_knowledge SET title=?,body=?,keywords=?,scope=? WHERE id=?',
      (title.strip(),body.strip(),keywords.strip(),scope,article_id))
    else:
     c.execute('INSERT INTO hr_knowledge(title,body,keywords,scope,source_label) VALUES (?,?,?,?,?)',
      (title.strip(),body.strip(),keywords.strip(),scope,'База знаний GPI Control — запись HR'))
    c.commit()
   return self.reply(200,{'ok':True})
  if path=='/api/hr/knowledge/delete':
   u=self.user()
   if not u:return self.reply(401,{'error':'Войдите в систему'})
   if u['role']!='admin':return self.reply(403,{'error':'Нет прав'})
   try:article_id=int(p.get('id'))
   except (ValueError,TypeError):return self.reply(400,{'error':'Неверная статья'})
   with LOCK,conn() as c:c.execute('DELETE FROM hr_knowledge WHERE id=?',(article_id,));c.commit()
   return self.reply(200,{'ok':True})
  if path=='/api/hr/notifications/read':
   u=self.user()
   if not u:return self.reply(401,{'error':'Войдите в систему'})
   with LOCK,conn() as c:
    c.execute('UPDATE hr_notices SET is_read=1 WHERE recipient=?',(u['login'],))
    c.execute('UPDATE training_events SET is_read=1 WHERE recipient=?',(u['login'],))
    c.commit()
   return self.reply(200,{'ok':True})
  if path=='/api/ai/config':
   u=self.user()
   if not u:return self.reply(401,{'error':'Войдите в систему'})
   if u['role']!='admin':return self.reply(403,{'error':'Настраивать ИИ может только HR'})
   model=p.get('model')
   if not isinstance(model,str) or not 1<=len(model)<=150 or model!=model.strip():
    return self.reply(400,{'error':'Укажите корректное название модели'})
   try: available=installed_models()
   except RuntimeError as e:return self.reply(503,{'error':str(e)})
   if model not in available:return self.reply(400,{'error':'Эта модель не установлена на основном компьютере'})
   with LOCK,conn() as c:
    c.execute('UPDATE ai_settings SET model=? WHERE id=1',(model,));c.commit()
   return self.reply(200,{'ok':True,'model':model})
  if path=='/api/ai/chat':
   u=self.user()
   if not u:return self.reply(401,{'error':'Войдите в систему'})
   messages=p.get('messages')
   if not isinstance(messages,list) or not 1<=len(messages)<=16:
    return self.reply(400,{'error':'Допустимо от 1 до 16 сообщений'})
   clean=[]
   for m in messages:
    if not isinstance(m,dict) or m.get('role') not in ('user','assistant') or not isinstance(m.get('content'),str) or not 0<len(m['content'])<=4000:
     return self.reply(400,{'error':'Неверный формат сообщения'})
    clean.append({'role':m['role'],'content':m['content']})
   if clean[-1]['role']!='user':return self.reply(400,{'error':'Последнее сообщение должно быть от пользователя'})
   now=time.time()
   with LOCK:
    recent=[t for t in AI_RATE.get(u['login'],[]) if now-t<60]
    if len(recent)>=6:return self.reply(429,{'error':'Не более 6 запросов AI Jana в минуту. Подождите.'})
    recent.append(now);AI_RATE[u['login']]=recent
   with LOCK,conn() as c: result=knowledge_answer(c,u,clean[-1]['content'])
   if result:return self.reply(200,result)
   return self.reply(200,{'answer':'Я не знаю: в доступной базе знаний нет подтверждённого ответа.', 'source':None,'source_label':None})
  if path=='/api/lesson-quiz/submit':
   u=self.user()
   if not u:return self.reply(401,{'error':'Войдите в систему'})
   try:
    course_id=int(p.get('course_id'));lesson_number=int(p.get('lesson_number'))
    answers=p.get('answers')
   except (TypeError,ValueError):return self.reply(400,{'error':'Неверные ответы'})
   with LOCK,conn() as c:
    course=c.execute('SELECT * FROM courses WHERE id=?',(course_id,)).fetchone()
    if not course or not training_visible(u,course):return self.reply(404,{'error':'Урок не найден'})
    enrollment=c.execute('SELECT status,completed FROM enrollments WHERE course_id=? AND login=?',(course_id,u['login'])).fetchone()
    if not enrollment or enrollment['status'] not in ('approved','completed'):
     return self.reply(403,{'error':'Нужна одобренная заявка'})
    row=c.execute('SELECT questions_json FROM lesson_quizzes WHERE course_id=? AND lesson_number=?',(course_id,lesson_number)).fetchone()
    if not row:return self.reply(404,{'error':'Тест не найден'})
    qs=json.loads(row['questions_json'])
    if not isinstance(answers,list) or len(answers)!=len(qs) or any(type(a)!=int or a<0 or a>=len(q['options']) for a,q in zip(answers,qs)):
     return self.reply(400,{'error':'Ответьте на все вопросы'})
    score=sum(a==q['answer'] for a,q in zip(answers,qs))
    c.execute('INSERT INTO lesson_quiz_results(course_id,lesson_number,login,score,total) VALUES (?,?,?,?,?) ON CONFLICT(course_id,lesson_number,login) DO UPDATE SET score=CASE WHEN lesson_quiz_results.total=excluded.total THEN MAX(lesson_quiz_results.score,excluded.score) ELSE excluded.score END,total=excluded.total,submitted_at=CURRENT_TIMESTAMP',
     (course_id,lesson_number,u['login'],score,len(qs)))
    passed=len(qs)>=4 and score*4>=len(qs)*3
    passed_count=c.execute('SELECT COUNT(*) AS n FROM lesson_quiz_results WHERE course_id=? AND login=? AND total>=4 AND score*4>=total*3',
      (course_id,u['login'])).fetchone()['n']
    new_progress=max(enrollment['completed'],min(course['lessons'],passed_count)) if 'completed' in enrollment.keys() else min(course['lessons'],passed_count)
    new_status='completed' if new_progress>=course['lessons'] else enrollment['status']
    if new_status=='completed' and enrollment['status']!='completed':
     training_notify(c,u['login'],f'Вы завершили курс «{course["title"]}»!')
    c.execute('UPDATE enrollments SET completed=?,status=? WHERE course_id=? AND login=?',
     (new_progress,new_status,course_id,u['login']))
    c.commit()
    return self.reply(200,{'score':score,'total':len(qs),'percent':round(score/len(qs)*100),
      'passed':passed,'completed_lessons':new_progress,'course_completed':new_status=='completed',
      'correct_answers':[q['answer'] for q in qs]})
  if path=='/api/quiz/submit':
   u=self.user()
   if not u:return self.reply(401,{'error':'Войдите в систему'})
   try:
    course_id=int(p.get('course_id'))
    answers=p.get('answers')
   except (ValueError,TypeError):return self.reply(400,{'error':'Неверные ответы'})
   with LOCK,conn() as c:
    course=c.execute('SELECT * FROM courses WHERE id=?',(course_id,)).fetchone()
    if not course or not training_visible(u,course):return self.reply(404,{'error':'Тест не найден'})
    enrollment=c.execute('SELECT status FROM enrollments WHERE course_id=? AND login=?',(course_id,u['login'])).fetchone()
    if not enrollment or enrollment['status'] not in ('approved','completed'):return self.reply(403,{'error':'Нужна одобренная заявка'})
    row=c.execute('SELECT questions_json FROM course_quizzes WHERE course_id=?',(course_id,)).fetchone()
    if not row:return self.reply(404,{'error':'Тест не найден'})
    questions=json.loads(row['questions_json'])
    if not isinstance(answers,list) or len(answers)!=len(questions) or any(type(a)!=int or a not in range(len(q['options'])) for a,q in zip(answers,questions)):
     return self.reply(400,{'error':'Ответьте на все вопросы'})
    score=sum(a==q['answer'] for a,q in zip(answers,questions))
    total=len(questions)
    c.execute('INSERT INTO quiz_results(course_id,login,score,total) VALUES (?,?,?,?) ON CONFLICT(course_id,login) DO UPDATE SET score=excluded.score,total=excluded.total,submitted_at=CURRENT_TIMESTAMP',(course_id,u['login'],score,total))
    c.commit()
    return self.reply(200,{'score':score,'total':total,'percent':round(score/total*100),'correct_answers':[q['answer'] for q in questions]})
  if path=='/api/login':
   with conn() as c:u=c.execute('SELECT * FROM users WHERE login=?',(str(p.get('login','')),)).fetchone()
   if not u or not validpass(str(p.get('password','')),u['passhash']):return self.reply(401,{'error':'Неверный логин или пароль'})
   token=secrets.token_urlsafe(32);SESSIONS[token]=(u['login'],time.time()+43200)
   return self.reply(200,{'user':public(u)},f'gpi_session={token}; HttpOnly; SameSite=Strict; Path=/; Max-Age=43200')
  if path=='/api/logout':
   cookies=SimpleCookie()
   try:
    cookies.load(self.headers.get('Cookie',''));SESSIONS.pop(cookies['gpi_session'].value,None)
   except (KeyError,AttributeError):pass
   return self.reply(200,{'ok':True},'gpi_session=; HttpOnly; SameSite=Strict; Path=/; Max-Age=0')
  if path.startswith('/api/training/'):
   u=self.user()
   if not u:return self.reply(401,{'error':'Войдите в систему'})
   action=path.split('/')[-1]
   with LOCK,conn() as c:
    if action=='create':
     if u['role'] not in ('admin','manager'):return self.reply(403,{'error':'Нет прав'})
     title=str(p.get('title','')).strip()[:120];description=str(p.get('description','')).strip()[:1500]
     department=str(p.get('department','Все'))
     try:lessons=int(p.get('lessons',1))
     except (TypeError,ValueError):lessons=0
     if not title or not 1<=lessons<=500 or (u['role']=='manager' and department!=u['department']):return self.reply(400,{'error':'Проверьте название, отдел и количество уроков'})
     c.execute('INSERT INTO courses(title,description,lessons,department,created_by) VALUES (?,?,?,?,?)',(title,description,lessons,department,u['login']))
     for member in c.execute('SELECT login,role,department,employeeId FROM users'):
      if member['login'].lower()==u['login'].lower():continue
      if department=='Все' or member['role']=='admin' or member['department']==department:
       training_notify(c,member['login'],f'Новый курс: {title}')
    elif action in ('edit','delete'):
     course=c.execute('SELECT * FROM courses WHERE id=?',(p.get('course_id'),)).fetchone()
     if not course:return self.reply(404,{'error':'Курс не найден'})
     if not training_manage(u,course):return self.reply(403,{'error':'Нет прав'})
     if action=='delete':
      c.execute('DELETE FROM enrollments WHERE course_id=?',(course['id'],))
      for table in ('course_quizzes','quiz_results','lesson_quizzes','lesson_materials','lesson_quiz_results'):
       c.execute('DELETE FROM '+table+' WHERE course_id=?',(course['id'],))
      c.execute('DELETE FROM courses WHERE id=?',(course['id'],))
     else:
      title=str(p.get('title','')).strip()[:120];description=str(p.get('description','')).strip()[:1500]
      try:lessons=int(p.get('lessons',1))
      except (TypeError,ValueError):lessons=0
      if not title or not 1<=lessons<=500:return self.reply(400,{'error':'Неверные данные курса'})
      c.execute('UPDATE courses SET title=?,description=?,lessons=? WHERE id=?',(title,description,lessons,course['id']))
      c.execute('UPDATE enrollments SET completed=MIN(completed,?) WHERE course_id=?',(lessons,course['id']))
    elif action=='apply':
     course=c.execute('SELECT * FROM courses WHERE id=?',(p.get('course_id'),)).fetchone()
     if not course:return self.reply(404,{'error':'Курс не найден'})
     dept=employee_department(u) if u['role']=='employee' else u['department'] if u['role']=='manager' else None
     if u['role']!='admin' and course['department'] not in ('Все',dept):return self.reply(403,{'error':'Курс недоступен'})
     if c.execute('SELECT id FROM enrollments WHERE course_id=? AND login=?',(course['id'],u['login'])).fetchone():return self.reply(409,{'error':'Заявка уже существует'})
     c.execute('INSERT INTO enrollments(course_id,login) VALUES (?,?)',(course['id'],u['login']))
     for manager in c.execute('SELECT login,role,department FROM users WHERE role IN ("admin","manager")'):
      if manager['role']=='admin' or manager['department']==course['department']:
       training_notify(c,manager['login'],f'Новая заявка: {u["name"]} — {course["title"]}')
    elif action=='review':
     e=c.execute('SELECT * FROM enrollments WHERE id=?',(p.get('enrollment_id'),)).fetchone()
     course=c.execute('SELECT * FROM courses WHERE id=?',(e['course_id'],)).fetchone() if e else None
     if not course:return self.reply(404,{'error':'Заявка не найдена'})
     if not training_manage(u,course):return self.reply(403,{'error':'Нет прав'})
     decision=p.get('status')
     if e['status']!='pending' or decision not in ('approved','rejected'):return self.reply(400,{'error':'Заявка уже рассмотрена или неверный статус'})
     c.execute('UPDATE enrollments SET status=? WHERE id=?',(decision,e['id']))
     training_notify(c,e['login'],f'Заявка на «{course["title"]}»: '+('одобрена' if decision=='approved' else 'отклонена'))
    elif action=='progress':
     e=c.execute('SELECT * FROM enrollments WHERE id=?',(p.get('enrollment_id'),)).fetchone()
     course=c.execute('SELECT * FROM courses WHERE id=?',(e['course_id'],)).fetchone() if e else None
     if not course:return self.reply(404,{'error':'Обучение не найдено'})
     if e['login'].lower()!=u['login'].lower():return self.reply(403,{'error':'Можно менять только свой прогресс'})
     if e['status'] not in ('approved','completed'):return self.reply(403,{'error':'Обучение ещё не одобрено'})
     if c.execute('SELECT 1 FROM lesson_materials WHERE course_id=? LIMIT 1',(course['id'],)).fetchone():return self.reply(403,{'error':'В этом курсе прогресс начисляется за успешные тесты уроков'})
     try:completed=int(p.get('completed',-1))
     except (TypeError,ValueError):completed=-1
     if not 0<=completed<=course['lessons']:return self.reply(400,{'error':'Неверный прогресс'})
     status='completed' if completed==course['lessons'] else 'approved'
     c.execute('UPDATE enrollments SET completed=?,status=? WHERE id=?',(completed,status,e['id']))
     if status=='completed' and e['status']!='completed':
      training_notify(c,u['login'],f'Курс «{course["title"]}» завершён')
    elif action=='read':
     c.execute('UPDATE training_events SET is_read=1 WHERE recipient=?',(u['login'],))
    else:return self.reply(404,{'error':'Не найдено'})
    c.commit()
   return self.reply(200,{'ok':True})
  if path=='/api/chat/send':
   u=self.user()
   if not u:return self.reply(401,{'error':'Войдите снова'})
   peer=p.get('recipient');body=p.get('body')
   if not isinstance(peer,str) or not isinstance(body,str) or not body.strip() or len(body)>2000:return self.reply(400,{'error':'Сообщение должно содержать от 1 до 2000 символов'})
   with LOCK,conn() as c:
    target=c.execute('SELECT login FROM users WHERE login=?',(peer,)).fetchone()
    if not target or target['login'].lower()==u['login'].lower():return self.reply(400,{'error':'Неверный получатель'})
    c.execute('INSERT INTO direct_messages(sender,recipient,body) VALUES(?,?,?)',(u['login'],target['login'],body.strip()))
    c.commit()
   return self.reply(200,{'ok':True})
  if path!='/api/state':return self.reply(404,{'error':'Не найдено'})
  u=self.user()
  if not u:return self.reply(401,{'error':'Войдите снова'})
  try:
   rev=p['revision'];new=p['data']
   if not isinstance(new,dict) or not isinstance(new.get('users'),list):raise ValueError()
   for k in ('employees','tasks','notifications','rewardsCatalog','rewardHistory'):
    if not isinstance(new.get(k),list):raise ValueError()
  except (KeyError,ValueError,TypeError):return self.reply(400,{'error':'Неверные данные'})
  with LOCK,conn() as c:
   oldrev,old=state(c)
   if rev!=oldrev:return self.reply(409,{'error':'Данные изменились на другом компьютере. Страница будет обновлена.'})
   seen=visible_state(old,u)
   # Workflow-owned progress can only be changed through /api/tasks/action.
   before_tasks={x['id']:x for x in seen.get('tasks',[])}
   for task in new.get('tasks',[]):
    previous=before_tasks.get(task.get('id'))
    if previous and (task.get('actual')!=previous.get('actual') or task.get('completedAt')!=previous.get('completedAt')):
     return self.reply(403,{'error':'Прогресс обновляется только через подтверждение задания'})
    if not previous and (float(task.get('actual') or 0)!=0 or task.get('completedAt')):
     return self.reply(400,{'error':'Новое задание должно начинаться с нулевого прогресса'})
   if not authorized(seen,new,u) or not check_users(seen,new,u) or not scoped_notifications_valid(seen,new,u):
    return self.reply(403,{'error':'Нет прав на это изменение'})
   try:
    sync_users(c,seen,new)
    new=merge_visible(old,new,u);new.pop('users',None)
    if isinstance(new.get('settings'),dict):new['settings'].pop('aiApiKey',None)
    c.execute('UPDATE state SET rev=?,data=? WHERE id=1',(rev+1,json.dumps(new,ensure_ascii=False)))
    c.commit()
   except sqlite3.IntegrityError:
    c.rollback();return self.reply(400,{'error':'Такой логин уже существует'})
  return self.reply(200,{'revision':rev+1})
if __name__=='__main__':
 init()
 print(f'GPI Control: http://127.0.0.1:{PORT} — для других компьютеров используйте IP хоста')
 print('База данных:',ROOT/'gpi_data.sqlite3')
 ThreadingHTTPServer((os.environ.get('GPI_HOST','0.0.0.0'),PORT),Handler).serve_forever()
