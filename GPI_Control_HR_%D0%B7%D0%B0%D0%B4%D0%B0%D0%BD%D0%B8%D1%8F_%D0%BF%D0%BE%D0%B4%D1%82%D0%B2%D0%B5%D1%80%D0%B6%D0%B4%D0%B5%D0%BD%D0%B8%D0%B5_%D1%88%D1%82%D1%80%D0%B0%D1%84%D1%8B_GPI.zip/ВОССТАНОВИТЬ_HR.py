# Run locally on the main computer, with server stopped.
import getpass
import hashlib
import secrets
import shutil
import sqlite3
from datetime import datetime
from pathlib import Path

root = Path(__file__).resolve().parent
db = root / 'gpi_data.sqlite3'
if not db.exists():
    print('База данных не найдена. Сначала запустите START_WINDOWS.bat.')
    input('Enter для выхода...')
    raise SystemExit(1)
print('Восстановление доступа GPI Control (только на основном компьютере).')
print('Сначала закройте окно сервера. Данные сотрудников и заданий сохранятся.')
password = getpass.getpass('Введите НОВЫЙ пароль HR (от 8 символов): ')
confirmation = getpass.getpass('Повторите новый пароль: ')
if len(password) < 8 or password != confirmation:
    print('Пароль слишком короткий или пароли не совпадают.')
    input('Enter для выхода...')
    raise SystemExit(1)
backup = root / ('gpi_data_backup_' + datetime.now().strftime('%Y%m%d_%H%M%S') + '.sqlite3')
with sqlite3.connect(db) as c:
    tables = {r[0] for r in c.execute("SELECT name FROM sqlite_master WHERE type='table'")}
    if 'users' not in tables:
        print('Неподдерживаемый формат базы данных.')
        input('Enter для выхода...')
        raise SystemExit(1)
    with sqlite3.connect(backup) as b:
        c.backup(b)
    salt = secrets.token_bytes(16)
    hashed = salt.hex() + '$' + hashlib.pbkdf2_hmac('sha256', password.encode(), salt, 260000).hex()
    # Recover admin only. Never touch state, tasks or other users.
    old = c.execute("SELECT login FROM users WHERE login=?", ('admin',)).fetchone()
    if old:
        c.execute("UPDATE users SET passhash=? WHERE login=?", (hashed, 'admin'))
    else:
        c.execute("INSERT INTO users (login,passhash,role,name,employeeId,department) VALUES (?,?,?,?,?,?)", ('admin', hashed, 'admin', 'HR', None, None))
    c.commit()
print('Пароль HR обновлён. Логин: admin')
print('Резервная копия:', backup.name)
print('Запустите START_WINDOWS.bat и войдите с новым паролем.')
input('Enter для выхода...')
